<?php




Class Functions
{
	
	private $pdo;
	public $msgErro = "";

	public function conectar($nome, $host, $usuario, $senha)
	{
		global $pdo;
		global $msgErro;
		try {
		$pdo = new PDO("mysql:dbname=".$nome.";host=".$host.":41890",$usuario,$senha);	
		} catch (PDOException $e) {
			$msgErro = $e->getMessage();
		}
	}

	public function cadastrarKey($chave, $secret, $idusuario)
	{
		global $pdo;
		//verificar se ja esta cadastrada
		$sql = $pdo->prepare("SELECT idchave FROM chave WHERE key = :k");
		$sql-> bindValue(":k", $chave);
		$sql->execute();
		if($sql->rowCount() > 0)
		{
			return false; //ja está cadastrada
		}
		else {
		//senao, cadastrar
		$sql = $pdo->prepare("DELETE FROM chave where usuarios_idusuario = :u");
	    $sql-> bindValue(":u", $idusuario);
		$sql->execute();
		$sql = $pdo->prepare("INSERT INTO chave (chave, secret, usuarios_idusuario) VALUE (:k, :s, :u)");
		$sql-> bindValue(":k", $chave);
		$sql-> bindValue(":s", $secret);
		$sql-> bindValue(":u", $idusuario);
		$sql->execute();
		//var_dump($sql->errorInfo());
		return true;

		}
	}

	public function cadastrarMsg($msg, $idusuario)
	{
		global $pdo;
		//verificar se ja esta cadastrada
		$sql = $pdo->prepare("SELECT idmensagen FROM mensagen WHERE msg = :m");
		$sql-> bindValue(":m", $msg);
		$sql->execute();
		if($sql->rowCount() > 0)
		{
			return false; //ja está cadastrada
		}
		else {
		//senao, cadastrar
		$sql = $pdo->prepare("DELETE FROM mensagen where usuarios_idusuario = :u");
	    $sql-> bindValue(":u", $idusuario);
		$sql->execute();
		$sql = $pdo->prepare("INSERT INTO mensagen (msg, usuarios_idusuario) VALUE (:m, :u)");
		$sql-> bindValue(":m", $msg);
		$sql-> bindValue(":u", $idusuario);
		$sql->execute();
		var_dump($sql->errorInfo());
		return true;

		}
	}
	


}


?>