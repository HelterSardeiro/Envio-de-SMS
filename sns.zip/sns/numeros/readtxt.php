<?php

function ListNumber($idusuario){
    $arq = 'upload/'.$idusuario.'.txt';
    $arquivo = fopen($arq, "r");
    $i=0;
    if(!feof($arquivo)){
        while(!feof($arquivo)){
        $linha[$i] = fgets($arquivo, 1024);
        $i++;
        }
        return $linha;
    }
    fclose($arquivo);
}

?>