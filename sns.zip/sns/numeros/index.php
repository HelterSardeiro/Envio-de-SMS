<?php
	session_start();
	if(!isset($_SESSION['idusuario']))
	{
        header("location: index.php");
        
		exit;
    }
    require_once 'api/CLASSES/functions.php';
    require_once 'readtxt.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="UpLoad">
    <meta name="author" content=".">
    <meta name="keywords" content="Upload Numeros">

    <!-- Title Page-->
    <title>Upload - Numeros</title>

    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
    
</head>

<body>
<?php 
    $path = 'upload/'.$_SESSION['idusuario'].'.txt';
    if (!file_exists($path)) {
?>
    <div class="page-wrapper bg-dark p-t-100 p-b-50">
        <div class="wrapper wrapper--w900">
            <div class="card card-6">
                <div class="card-heading">
                    <h2 class="title">Enviar arquivo</h2>
                </div>
                <div class="card-body">
                    <form action="#" method="POST" enctype="multipart/form-data">
                        <div class="form-row">
                            <div class="name">Upload TXT</div>
                            <div class="value">
                                <div class="input-group js-input-file">
                                    <input class="input-file" type="file" name="fileUpload" id="file">
                                    <label class="label--file" for="file">Procurar Arquivo</label>
                                    <span class="input-file__info">Nenhum arquivo selecionado</span>
                                </div>
                                <div class="label--desc">Faça upload do arquivo TXT.</div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button class="btn btn--radius-2 btn--blue-2" type="submit">Upload</button>
                    
                            
                    
                 </div>
                        
                    </form>
                </div>
                
            </div>
        </div>
    </div>

    <?php 
    }
    ?>

<div class="page-wrapper bg-dark p-t-100 p-b-50">

        <div class="wrapper wrapper--w900">
            <div class="card card-6">
                <div class="card-heading">
                    <h2 class="title">Painel</h2>
                </div>
                <div class="card-body">
                  
                    <a class="btn btn--radius-2 btn--blue-2" href="upload.php">Adicionar Nova Lista?</a>
                  
                
                    <a class="btn btn--radius-2 btn--blue-2" href="cadastrark.php">Cadastro de Chave</a>
               
                  
                    <a class="btn btn--radius-2 btn--blue-2" href="cadastrarm.php">Cadastro de Mensagen</a>

                    <a class="btn btn--radius-2 btn--blue-2" href="api/exec.php">Executar Envios</a>
                    <p style="hight:20px;">&nbsp;</p>
                </div>
                
            </div>
        </div>  <p style="hight:20px;">&nbsp;</p>
            <div style="background:#22DDAA; hight:90px; width: 330px;">
            <?php
                if(isset($_SESSION['idusuario']))
                {
                    $u = new Functions;
                    $u->conectar("sns", "mysql22.redehost.com.br", "ultraconsultas", "Rod20271179#");
                    $chave = $u->ListChave($_SESSION['idusuario']);
                    $msg = $u->ListMsg($_SESSION['idusuario']);
                    $number = ListNumber($_SESSION['idusuario']);
                    if(!empty($chave)){
                        echo "<p>Chaves Já se encontra cadastrada <i class='fas fa-check-circle'></i></p>";
                    }
                    if(!empty($msg)){
                        echo "<p>Mensagem Já se encontra cadastrada <i class='fas fa-check-circle'></i></p>";
                    }
                    if(!empty($number)){
                        echo "<p>Lista de numeros Já se encontra cadastrada <i class='fas fa-check-circle'></i></p>";
                    }
                }

            ?>
            </div>
    </div>

    <?php

if ($_SERVER["REQUEST_METHOD"] === "POST") {
	$file = $_FILES["fileUpload"];
	if ($file["error"]){
		throw new Exception("ERROR: ".$file["error"]);
		
	}
	$dirUploads = "upload";
	if(!is_dir ($dirUploads)){
		mkdir($dirUploads);
    }

      $ext = strtolower(substr($_FILES['fileUpload']['name'],-4)); //Pegando extensão do arquivo
      $new_name = $_SESSION['idusuario'].$ext;
	if (move_uploaded_file($file["tmp_name"], $dirUploads . DIRECTORY_SEPARATOR . $new_name)){
        echo "<script>alert('upload realizado com sucesso');</script>";
        header("location: index.php");
	} else{
		throw new Exception("Não Foi possivel realizar o upload.");
		
	}
}
?>
    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>


    <!-- Main JS-->
    <script src="js/global.js"></script>

</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html>
<!-- end document-->