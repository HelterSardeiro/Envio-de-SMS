<?php
	require_once 'CLASSES/functions.php';
	$u = new Functions;
?>
<?php
	session_start();
	if(!isset($_SESSION['idusuario']))
	{
		header("location: index.php");
		exit;
	}
?>
<html lang="pt-br">
<head>
	<title>Key</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/estilos.css">
	<meta name="viewport" content="width:device-width, initial-scale=1">

</head>
<body>
	<form class="box" method="POST">
				<h1>Adicionar Chaves</h1>
				<input type="text" name="chave" placeholder="Chave" maxlength="30">
				<input  type="text" name="secret" placeholder="Chave Secreta" maxlength="40">
				<input type="submit" value="Cadastrar">

			</form>

<?php
//verificar se clicou em cadastrar(submit)
if(isset($_POST['chave']))
{
	$chave = $_POST['chave'];
	$secret = $_POST['secret'];
	$idusuario = $_SESSION['idusuario'];
	//verificar se esta preenchido
	if(!empty($chave) && !empty($secret) && !empty($idusuario))
	{
		$u->conectar("sns", " ", " ", " ");
		if($u->msgErro == "")
		{
			
			if($u->cadastrarKey($chave, $secret, $idusuario))
			{
					?>
					<div id="msg-sucesso">
					 	Cadastrado com sucesso!
					</div>
					<?php
					echo "<script>alert('cadastro realizado com sucesso!');</script>";
					header("location: index.php");
			} else{
				echo "<div class='msg-erro'>Erro!</div>";
			}
		}
		else
		{
			?>
			<div class="msg-erro">
				<?php echo "Erro: ".$u->msgErro;?>
			</div>
			<?php
		}
	} else
	{	
		?>
		<div class="msg-erro">
			Preencha todos os campos!
		</div>
		<?php
	}
}

?>

</body>
</html>