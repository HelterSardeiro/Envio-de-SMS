<?php
// Reference taken from: https://docs.aws.amazon.com/aws-sdk-php/v3/api/api-sns-2010-03-31.html#publish
require 'vendor/autoload.php';
use Aws\Sns\SnsClient;
// Instantiate the client with your AWS access keys
// Create a new Amazon SNS client
// Make sure the region you enter does have support for sending SMS text messages directly

function Sns($chave, $secret, $number, $msg){
    $sns = SnsClient::factory(array(
        'region' => 'ap-southeast-2',
        'version' => 'latest',
        'credentials' => [
            'key' => $chave,
            'secret' => $secret,
        ]
        ));
    //this variable to be used for attributes with each message that you want to send out
    $msgattributes = [
        'AWS.SNS.SMS.SenderID' => [
            'DataType' => 'String',
            'StringValue' => 'mySenderID',
        ],
        'AWS.SNS.SMS.SMSType' => [
            'DataType' => 'String',
            'StringValue' => 'Transactional',
        ]
    ];
    $payload = array(
        'Message' => $msg,
        'PhoneNumber' => $number,
        'MessageAttributes' => $msgattributes
    );
    //var_dump($payload);
    try {
       // echo "\nConfiguration Response:\n";
      //  echo "\nPublish Response:\n";
      //  $result=$sns->publish($payload);
    //	var_dump($result);
        //echo "\nMensagem Enviada com sucesso!!!\n";
        return true;
    } catch ( Exception $e ) {
        return false;
        //echo "Send Failed!\n" . $e->getMessage();
    }
}
//Sns('','','');

?>


