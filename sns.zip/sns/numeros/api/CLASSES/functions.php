<?php




Class Functions
{
	
	private $pdo;
	public $msgErro = "";

	public function conectar($nome, $host, $usuario, $senha)
	{
		global $pdo;
		global $msgErro;
		try {
		$pdo = new PDO("mysql:dbname=".$nome.";host=".$host.":41890",$usuario,$senha);	
		} catch (PDOException $e) {
			$msgErro = $e->getMessage();
		}
	}
	public function ListChave($idusuario){
		global $pdo;
		$select = $pdo->query("
		SELECT chave, secret
		FROM chave
		WHERE usuarios_idusuario = ".$idusuario); 
 
		$result = $select->fetch(PDO::FETCH_ASSOC);
		return $result;
	}

	public function ListMsg($idusuario){
		global $pdo;
		$select = $pdo->query("
		SELECT msg
		FROM mensagen
		WHERE usuarios_idusuario = ".$idusuario); 
 
		$result = $select->fetch(PDO::FETCH_ASSOC);
		return $result;
	}


}

?>