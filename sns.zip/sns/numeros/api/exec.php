<?php
	require_once 'CLASSES/functions.php';
	require_once 'index.php';
	require_once 'readtxt.php';
	$u = new Functions;
?>
<?php
	session_start();
	if(!isset($_SESSION['idusuario']))
	{
		header("location: index.php");
		exit;
	}
?>
<html lang="pt-br">
<head>
	<title>Key</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/estilos.css">
	<meta name="viewport" content="width:device-width, initial-scale=1">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>

<table class="table table-striped table-inverse table-responsive">
	<thead class="thead-inverse">
		<tr>
			<th>Chave</th>
			<th>Chave Secreta</th>
			<th>Numero</th>
			<th>Mensagem</th>
			<th>Status</th>
		</tr>
		</thead>
		<tbody>
			


<?php
	$u->conectar("sns", "mysql22.redehost.com.br", "ultraconsultas", "Rod20271179#");
	$chave = $u->ListChave($_SESSION['idusuario']);
	$msg = $u->ListMsg($_SESSION['idusuario']);
	$number = ListNumber($_SESSION['idusuario']);
	$t = count($number);
	for($i = 0; $i < $t; $i++){
		if(Sns($chave['chave'], $chave['secret'], $number[$i], $msg['msg'])){
			$stt = "<i class='fas fa-check-circle'></i>";
		} else{
			$stt = "<i class='fas fa-times-circle'></i>";
		}
		echo "<tr>
		<td scope='row'>".$chave['chave']."</td>
		<td>".$chave['secret']."</td>
		<td>".$number[$i]."</td>
		<td>".$msg['msg']."</td><td>".$stt."</td>
	</tr>";
	
	//Sns($chave['chave'], $chave['secret'], $number[$i], $msg['msg']);
	}
	
?>
		</tbody>
</table>

</body>
</html>